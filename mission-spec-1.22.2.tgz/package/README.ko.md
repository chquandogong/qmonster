<p align="center">
  <a href="https://github.com/chquandogong/mission-spec/blob/main/README.md">English</a> | 한국어 | <a href="https://github.com/chquandogong/mission-spec/blob/main/README.zh.md">中文</a>
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/chquandogong/mission-spec/main/.github/assets/mission-spec-banner.svg" alt="Mission Spec — AI 에이전트 워크플로를 위한 task contract layer" width="100%">
</p>

<h1 align="center">Mission Spec</h1>

<p align="center">
  <strong>AI 에이전트 워크플로를 위한 task contract layer.</strong><br>
  Portable mission 파일, 명시적 완료 gate, 감사 가능한 변경 원장을 제공합니다.
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/mission-spec"><img alt="npm version" src="https://img.shields.io/npm/v/mission-spec?color=cb3837"></a>
  <a href="https://github.com/chquandogong/mission-spec/actions/workflows/test.yml"><img alt="test workflow" src="https://github.com/chquandogong/mission-spec/actions/workflows/test.yml/badge.svg?branch=main"></a>
  <a href="https://github.com/chquandogong/mission-spec/actions/workflows/release.yml"><img alt="release workflow" src="https://github.com/chquandogong/mission-spec/actions/workflows/release.yml/badge.svg"></a>
  <a href="https://github.com/chquandogong/mission-spec/blob/main/LICENSE"><img alt="license" src="https://img.shields.io/github/license/chquandogong/mission-spec"></a>
  <a href="#npm-패키지-vs-저장소-v1215"><img alt="npm provenance" src="https://img.shields.io/badge/npm%20provenance-sigstore-2f7de1"></a>
  <a href="#방법-2-claude-code-플러그인으로-설치"><img alt="Claude Code plugin" src="https://img.shields.io/badge/Claude%20Code-plugin-6f42c1"></a>
</p>

<p align="center">
  <a href="#5분-설치-가이드">설치</a> ·
  <a href="#사용법">사용법</a> ·
  <a href="#명시적-gate-연결-v1210">Evaluation gates</a> ·
  <a href="#living-asset-registry-v150">Registry</a> ·
  <a href="https://github.com/chquandogong/mission-spec/blob/main/DOCUMENTATION.md">문서 인덱스</a> ·
  <a href="CONTRIBUTING.md">기여 가이드</a>
</p>

Mission Spec은 orchestration framework가 아닙니다. 기존 하네스 위에서 작동하는 portable한 run-scoped task contract입니다. TypeScript 라이브러리, CLI, Claude Code용 skill bundle, 그리고 **Living Asset Registry**를 함께 제공합니다.

## 한눈에 보기

| 계층 | 제공하는 것 |
| --- | --- |
| Contract | `mission.yaml`에 목표, 제약, 완료 조건, design reference를 기록합니다. |
| Evaluation | `evals[]` + `done_when_refs[]`로 automated, manual, LLM-eval, LLM-judge gate를 지원합니다. |
| Reporting | CLI/API가 status, eval, report, context, snapshot, backfill 출력을 생성합니다. |
| Governance | `mission-history.yaml`, MDR, snapshot, architecture/API registry, traceability asset으로 변경 이유를 보존합니다. |
| Distribution | sigstore provenance가 붙은 npm package와 Claude Code plugin/skill bundle을 제공합니다. |

## 빠른 링크

| 필요 | 시작 위치 |
| --- | --- |
| 설치 또는 CLI 실행 | [5분 설치 가이드](#5분-설치-가이드) |
| TypeScript에서 사용 | [사용법](#사용법) |
| 완료 gate 이해 | [명시적 gate 연결](#명시적-gate-연결-v1210) |
| 프로젝트 이력 감사 | [Living Asset Registry](#living-asset-registry-v150)와 [`mission-history.yaml`](mission-history.yaml) |
| 긴 문서 탐색 | [문서 인덱스](https://github.com/chquandogong/mission-spec/blob/main/DOCUMENTATION.md) |

## 핵심 파이프라인

```text
자연어 → mission.yaml draft → eval scaffold → run report
                  ↕
         mission-history.yaml (변경 원장)
```

## 5분 설치 가이드

### 방법 1: npm에서 설치 (v1.21.4부터 권장)

```bash
# 의존성으로 설치
npm install mission-spec

# dev 도구로만 설치
npm install --save-dev mission-spec

# 전역 설치 없이 CLI 사용
npx mission-spec validate
npx mission-spec snapshot
npx mission-spec backfill-commits
```

라이브러리 API:

```typescript
import {
  generateMissionDraft,
  evaluateMission,
  getMissionStatus,
  generateMissionReport,
} from "mission-spec";
```

이 패키지는 sigstore provenance와 함께 npm에 배포됩니다 — `npm view mission-spec@<version> --json`의 `dist.attestations`로 검증할 수 있습니다.

### 방법 2: Claude Code 플러그인으로 설치

```bash
# Claude Code 안에서 실행
/plugin marketplace add chquandogong/mission-spec
/plugin install mission-spec@mission-spec
```

설치 후 다음 skill을 바로 사용할 수 있습니다:

- `/mission-spec:ms-init` — 자연어 → mission.yaml 초안 자동 생성
- `/mission-spec:ms-eval` — done_when 기준 대비 현재 상태 평가
- `/mission-spec:ms-status` — 미션 진행 상황 요약
- `/mission-spec:ms-report` — run report 생성 (markdown)
- `/mission-spec:ms-context` — AI 에이전트를 위한 프로젝트 컨텍스트 프롬프트 생성 (v1.7.0+)
- `/mission-spec:ms-decide` — 자연어 결정 설명으로부터 MDR(Mission Decision Record) 초안 생성 (v1.14.0+)

### 방법 3: 소스에서 설치 (기여자용)

```bash
git clone https://github.com/chquandogong/mission-spec.git
cd mission-spec
npm install
npm run build
```

### 방법 4: 프로젝트에 로컬 플러그인으로 연결

```bash
# 프로젝트 디렉토리에서
git clone https://github.com/chquandogong/mission-spec.git .mission-spec
cd .mission-spec && npm install && npm run build && cd ..
```

`.claude/settings.json`에 플러그인 경로를 추가합니다:

```json
{
  "plugins": [".mission-spec"]
}
```

## 사용법

### Mission 초안 생성 (`ms-init`)

```typescript
import { generateMissionDraft } from "mission-spec";

const result = generateMissionDraft({
  goal: "사용자 인증 시스템을 구현한다",
  projectDir: ".",
});

console.log(result.yaml);
```

### 진행 상황 평가 (`ms-eval`)

```typescript
import { evaluateMission } from "mission-spec";

const result = evaluateMission(".");
console.log(result.summary);
```

fresh clone 또는 공유 저장소 리뷰에서는 `evaluateMission(".", { scope: "shared" })`
또는 `npx mission-spec eval --shared`를 사용할 수 있습니다. shared mode는
missing gitignored local-only artifact만 가리키는 criterion을 skip/pass 처리합니다.

### 상태 요약 (`ms-status`)

```typescript
import { getMissionStatus } from "mission-spec";

const status = getMissionStatus(".");
console.log(status.markdown);
```

`getMissionStatus(".", { scope: "shared" })`와 `npx mission-spec status --shared`도
같은 shared-clone 동작을 status/drift 보고에 적용합니다.

### 리포트 생성 (`ms-report`)

```typescript
import { generateMissionReport } from "mission-spec";

const report = generateMissionReport(".");
console.log(report.markdown);
```

### AI 에이전트 컨텍스트 생성 (`ms-context`)

```typescript
import { generateContext } from "mission-spec";

const ctx = generateContext(".");
console.log(ctx.markdown); // mission + history + architecture + API 통합 프롬프트
console.log(ctx.sections); // ["mission", "design_refs", "history", "decisions", "architecture", "api"]
```

### MDR 초안 생성 (`ms-decide`)

```typescript
import { generateMdrDraft } from "mission-spec";

const result = generateMdrDraft({
  title: "Vendor-neutral 플랫폼 어댑터 채택",
  projectDir: ".",
});

console.log(result.suggestedPath); // .mission/decisions/MDR-00N-vendor-neutral-...md
console.log(result.nextMdrNumber); // 다음 MDR 번호
console.log(result.markdown); // Context / Decision / Rationale / Consequences / Alternatives 섹션 스캐폴드
```

파일명은 Unicode NFC + `/u` 플래그로 slugify되어 한글/중문/일문 제목도 안정적으로 파일명 생성 (v1.14.1+).

필요하면 subpath import도 사용할 수 있습니다:

```typescript
import { evaluateMission } from "mission-spec/commands/eval";
```

Migration 스크립트는 목표 schema 버전을 명시해야 합니다:

```bash
npm run migrate:dry-run -- <toVersion>
npm run migrate:apply -- <toVersion>
```

아직 등록된 migrator는 없으며, schema v2가 정의될 때까지 registry는 비어 있습니다.

## mission.yaml 형식

```yaml
mission:
  title: "미션 제목"
  goal: "미션 목표"
  done_when:
    - "완료 조건 1"
    - "완료 조건 2"
  constraints:
    - "제약 조건"
  approvals:
    - gate: "review"
      approver: "human"
  execution_hints:
    topology: "sequential"
  design_refs: # v1.7.0+
    architecture: "docs/internal/ARCHITECTURE.md"
    api_surface: "src/index.ts"
    type_definitions: "src/core/parser.ts"
    component_protocol: "docs/internal/DATA_FLOW.md"
  lineage: # v1.5.0+
    initial_version: "1.0.0"
    initial_date: "2026-04-02"
    total_revisions: 3
    history: "mission-history.yaml"
```

전체 스키마: [`src/schema/mission.schema.json`](src/schema/mission.schema.json)

## Living Asset Registry (v1.5.0)

mission.yaml의 변경 이력을 구조화하여 회사 자산으로 관리합니다.

### 구조

```
project-root/
├── mission.yaml                    # 현재 authoritative spec
├── mission-history.yaml            # 구조화된 변경 원장
└── .mission/
    ├── CURRENT_STATE.md            # 현재 상태 대시보드
    ├── snapshots/                  # 버전별 mission.yaml 원본
    ├── decisions/                  # MDR (Mission Decision Records)
    └── templates/                  # 변경 항목 + MDR 템플릿
```

### mission-history.yaml

변경의 의도, 영향 범위, 완료 조건 변화를 구조화된 YAML로 추적합니다:

```yaml
timeline:
  - change_id: "MSC-2026-04-08-001"
    semantic_version: "1.5.0"
    date: "2026-04-08"
    author: "Dr. QUAN"
    change_type: "enhancement"
    persistence: "permanent" # permanent | transient | experimental
    intent: "Living Asset Registry 도입"
    done_when_delta: # 완료 조건의 변화 추적
      added: [".claude-plugin/plugin.json 존재"]
      removed: []
    impact_scope:
      schema: true
      skills: true
```

### lineage 필드

`ms-init`으로 새 mission을 생성하면 `lineage` 필드가 자동으로 포함됩니다:

```yaml
lineage:
  initial_version: "1.0.0"
  history: "mission-history.yaml"
```

### 도구 연동

- **ms-status**: `mission-history.yaml`을 읽어 현재 phase와 진화 요약을 출력
- **ms-report**: 최근 3건의 변경 이력을 리포트에 포함
- **ms-init**: 새 mission 생성 시 `lineage` + `version` 자동 생성

### History API

```typescript
import {
  loadHistory,
  getCurrentPhase,
  getLatestEntry,
  validateHistory,
} from "mission-spec";

const history = loadHistory("."); // schema 오류 시 throw (v1.6.0+)
if (history) {
  console.log(getCurrentPhase(history)); // { name: "living-asset", theme: "..." }
  console.log(getLatestEntry(history)); // 최신 timeline 항목
}

// 임의 데이터를 mission-history.yaml 스키마로 검증
const { valid, errors } = validateHistory(anyData);
```

## LLM/주관 평가 (v1.6.0+)

`done_when` 조건 중 기계적으로 판정하기 어려운 항목은 `llm-eval` 또는 `llm-judge` 타입 eval로 정의하고, 외부 판정을 `.mission/evals/<eval-name>.result.yaml`에 기록합니다:

```yaml
# mission.yaml
done_when:
  - "subjective_quality"
evals:
  - name: "subjective_quality"
    type: "llm-eval" # 또는 "llm-judge"
    pass_criteria: "UX가 직관적이고 사용자 혼란 없음"
```

```yaml
# .mission/evals/subjective_quality.result.yaml
passed: true
reason: "리뷰어 3인 판정"
evaluated_by: "human" # 또는 "llm-claude", "llm-gpt5" 등
evaluated_at: "2026-04-13"
```

`ms-eval`은 오버라이드 파일을 읽어 판정을 확정합니다. 파일이 없으면 `LLM 검증 대기` 상태로 유지됩니다.

## 스냅샷 및 pre-commit 훅 (v1.6.0+)

`mission.yaml`이 변경될 때마다 버전별 스냅샷을 `.mission/snapshots/`에 자동으로 아카이브할 수 있습니다:

```bash
# 수동 스냅샷 생성
npm run snapshot

# 커밋 시 자동 스냅샷 (한 번만 설정)
git config core.hooksPath .githooks
```

스냅샷 스크립트는 버전 기반 dedup을 수행 — 같은 `version`의 스냅샷이 이미 있으면 생성하지 않습니다.

또한 `npm run validate:history-commits`로 `mission-history.yaml`의 `related_commits`와 실제 Git 이력을 대조할 수 있습니다. 이 저장소의 체크인된 `.githooks/pre-commit`은 현재 다음 작업을 수행합니다.

- snapshot 생성 및 스테이징
- CHANGELOG 재생성 및 스테이징
- `.mission/` 메타데이터 헤더 동기화 및 스테이징
- Architecture snapshot 동기화/검증 (`dist/core`가 있을 때)
- `npm run validate:history-commits` 기반 `related_commits` 커버리지 검사

이 검증은 이미 커밋된 관련 commit이 history에 누락됐는지도 잡아냅니다. 단, self-reference 문제를 피하기 위해 `mission-history.yaml`을 **처음 도입한 bootstrap commit 1건**과, **현재 HEAD가 `mission-history.yaml`을 함께 수정한 경우**만 예외 처리합니다. 이후 다른 commit이 쌓이면, 그 이전 code+history 동시 commit도 다시 검사 대상이 됩니다.

## 커밋 전 검증 (v1.17.0+)

`mission.yaml` + `mission-history.yaml`의 스키마 무결성을 commit 시점에 강제합니다. evaluator 호출 없이 스키마만 검사하므로 빠르고 deterministic — 스키마 drift가 repo에 유입되기 전 commit을 차단.

기본 설치 (`.git/hooks/`):

```bash
npm install --save-dev mission-spec
cp node_modules/mission-spec/templates/pre-commit .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

팀 공유 변형 (`.githooks/` + `core.hooksPath`):

```bash
mkdir -p .githooks
cp node_modules/mission-spec/templates/pre-commit .githooks/pre-commit
chmod +x .githooks/pre-commit
git config core.hooksPath .githooks
```

배포되는 `templates/pre-commit` 훅은 `npx mission-spec validate`를 호출하며, 같은 명령을 CI / 수동 검증에 독립적으로 사용할 수도 있습니다. 이 저장소의 체크인된 `.githooks/pre-commit`은 그 위에 maintainer용 자동화를 추가로 올려둔 형태입니다.

비어 있는 `changes.*` / `done_when_delta.*` 배열을 생략한 legacy
`mission-history.yaml` entry는 validation 전에 normalize합니다. 타입이 잘못된 값은
계속 실패합니다.

## related_commits 백필 (v1.18.0+)

`mission-history.yaml`의 빈 `related_commits: []` 항목을 각 revision date의 ±1-day 범위 git commit과 매칭해 채워 넣습니다. 기본은 dry-run, `--apply` 시 단일 후보 엔트리를 파일에 직접 기록.

```bash
# 제안만 확인 (쓰지 않음)
npx mission-spec backfill-commits

# 단일 후보 엔트리를 일괄 적용
npx mission-spec backfill-commits --apply
git add mission-history.yaml
git commit -m "chore: backfill related_commits via ms-backfill-commits"
```

엔트리별 분류:

- **auto-apply** — window 내 commit이 정확히 1개; `--apply` 시 기록.
- **ambiguous** — window 내 commit이 2개 이상; 나열하되 기록하지 않음 (수동 편집 필요).
- **no-candidates** — window 내 commit이 0개; 나열하되 작업 없음.

이미 채워진 `related_commits` 배열은 **절대 덮어쓰지 않습니다**.

## 커밋 시 snapshot (v1.19.0+)

`.mission/snapshots/`에 `mission.yaml`의 버전별 사본을 생성합니다. `mission.version`별 idempotent — 같은 버전으로 재호출하면 기존 snapshot을 반환(중복 생성 없음). 언어 독립적 — Node + mission-spec 설치된 어느 프로젝트에서도 동작.

```bash
# 단독 호출
npx mission-spec snapshot
```

adopter용 최소 hook 예시 (v1.17.0 validate + v1.19.0 snapshot 결합):

```sh
#!/bin/sh
set -e
npx mission-spec validate
npx mission-spec snapshot
git add .mission/snapshots/
```

기존 v1.17.0 adopter는 설치된 `.git/hooks/pre-commit`에 `snapshot` + `git add` 두 줄만 추가. 패키지에 포함된 `templates/pre-commit` 파일은 그대로(단일 validate 호출) 유지되므로 `cp` 재설치는 필요 없음.

## 명시적 gate 연결 (v1.21.0+)

`mission.yaml`은 optional `done_when_refs` sibling 필드를 지원합니다. 각 prose `done_when` 조건을 explicit validator에 바인딩할 수 있습니다. 4가지 `kind` 지원: `command` (POSIX shell, exit 0), `file-exists` (파일 경로), `file-contains` (`path::substring` 형식), `eval-ref` (`mission.evals[].name`으로 위임). 각 ref는 `index`로 대상 `done_when` 엔트리에 연결됩니다.

지속 가능한 패턴은 `eval-ref`입니다. `done_when` 문구는 사람이 읽기 좋게 유지하고, 실제 검증은 `evals[]`에 둡니다. `evals[].type`은 `automated`(command 실행), `manual`(외부 verdict 파일이 있는 사람 gate), `llm-eval`, `llm-judge`(`.mission/evals/` 아래 외부 verdict 파일)를 지원합니다. 현재 runtime scoring은 네 타입 모두를 처리합니다.

```yaml
mission:
  done_when:
    - "cargo test가 통과한다"
    - "README에 installation 섹션이 있다"
  done_when_refs:
    - index: 0
      kind: command
      value: "cargo test"
    - index: 1
      kind: file-contains
      value: "README.md::## Installation"
```

바인딩된 index는 해당 validator를 직접 실행(`resolved_by: "ref"`)하고, 바인딩 없는 index는 v1.20.0 inference chain으로 fallback 합니다. `ms-status`는 refs가 있을 때 `## refs coverage` 섹션을 추가하고 drift 판정을 `resolved_by === "manual"` 기준으로 재분류하며, `validateProject`는 3가지 invariant(index 범위, 중복, `eval-ref` orphan)를 강제합니다. `eval`, `status`, `report`는 `mission.yaml`에 선언된 command를 실행할 수 있으므로 신뢰한 저장소에서만 사용하고, schema-only 확인은 `mission-spec validate`를 사용하세요. 릴리스 등급: MDR-006 §MINOR.

## npm 패키지 vs 저장소 (v1.21.5+)

`mission-spec` npm 패키지는 런타임 필수 요소만 포함합니다: `bin/`, `dist/`, `skills/`, `.claude-plugin/`, `templates/`, 그리고 3개 로케일 README.

**npm tarball에 포함되지 않는 것** (install 크기를 작게 유지하려는 의도):

- `.mission/` — Living Asset Registry (진화 이력, MDR, 스냅샷, 추적성, 재구성 playbook, 검증 로그)
- `mission-history.yaml` — 결정과 관련 commit이 포함된 전체 revision timeline
- 소스 TypeScript, tests, scripts

Mission Spec의 진화를 보려면 **저장소에서** `.mission/`과 `mission-history.yaml`을 읽으세요 (https://github.com/chquandogong/mission-spec). 저장소에는 63개 스냅샷(v1.0.0 → 현재), 9개 MDR, 그리고 전체 architecture/API/traceability registry가 있습니다.

**Two-track 신뢰 모델**: npm tarball은 provenance 서명(sigstore, `npm view mission-spec@<version> --json`으로 검증 가능)되어 있으므로 빌드를 신뢰할 수 있습니다. 저장소는 계약의 진화를 감사하는 장소입니다. 두 경로는 설계상 분리되어 있습니다.

## Cross-Platform 변환

```bash
node scripts/convert-platforms.js mission.yaml
```

생성 파일 (v1.14.0+ — 6개 플랫폼):

- `.cursorrules` — Cursor용
- `AGENTS.md` — Codex용
- `opencode.toml` — OpenCode용
- `.clinerules` — Cline용 (v1.14.0+)
- `.continuerules` — Continue용 (v1.14.0+)
- `.aider.conf.yml` + `.aider-mission.md` — Aider용 (v1.14.0+)

검증만 수행하려면:

```bash
node scripts/convert-platforms.js --verify
```

## 검증

```bash
npm run lint
npm run build
npm test
npm run registry:check
node scripts/verify-registry.js --verify-live
```

CI는 Node.js 20과 22에서 같은 핵심 gate를 실행합니다. release workflow는 여기에 plugin 검증, architecture 검증, reconstruction cold-build, npm provenance publish를 추가로 수행합니다.

## 현재 범위

- 제공 중: schema validation, mission draft generation, rule-based evaluation, status/report generation
- 제공 중: cross-platform conversion for Cursor, Codex, OpenCode, Cline, Continue, Aider (v1.14.0+)
- 제공 중: Claude Code skill files `ms-init`, `ms-eval`, `ms-status`, `ms-report`, `ms-context`, `ms-decide`
- 제공 중: CLI — `npx mission-spec <context|status|eval|report|validate|backfill-commits|snapshot>` (v1.12.0+, 이후 릴리스에서 확장)
- 제공 중: Living Asset Registry — `lineage` 스키마, `mission-history.yaml` 변경 원장, MDR, 스냅샷
- 제공 중: history API — `loadHistory()`, `getCurrentPhase()`, `getLatestEntry()`, `validateHistory()`
- 제공 중: LLM/주관 평가 오버라이드 (`llm-eval`, `llm-judge` + `.mission/evals/<name>.result.yaml`)
- 제공 중: 스냅샷 자동화 (`npm run snapshot`, `.githooks/pre-commit`)
- 제공 중: `design_refs` 스키마 필드 + `architecture_delta` history 필드 (v1.7.0+)
- 제공 중: Architecture Registry, Dependency Graph, API Registry, Traceability Matrix (`.mission/` 하위)
- 제공 중: Architecture/plugin drift detector — `extractArchitecture()`, `validatePlugin()`, `arch:sync`/`check`/`verify` (v1.10.0+, v1.11.0+)
- 제공 중: MDR 작성 보조 — `ms-decide` skill + `generateMdrDraft()` (v1.14.0+)
- 제공 중: Schema migration 인프라 — `detectSchemaVersion()`, `registerMigration()`, `migrateMission()` + CLI wrapper `npm run migrate:dry-run -- <toVersion>` / `npm run migrate:apply -- <toVersion>` (v1.14.0+, schema v2까지 registry 비어있음)
- 제공 중: Reconstruction verifier — `verifyReconstructionReferences()` + `reconstruction:verify [--cold-build]` (v1.14.0+)
- 제공 중: Release pipeline — `.github/workflows/{test,pre-commit-parity,release}.yml` (v1.9.0+, v1.13.0+)
- 제공 중: `.mission/` 메타데이터 auto-sync — `scripts/bump-metadata.js`가 Version 헤더와 CURRENT_STATE Title 라인을 `mission.yaml`에서 자동 동기화 (`npm run metadata:sync` / `metadata:check`, v1.15.0+, v1.16.3+ Title, v1.16.10+ CURRENT_STATE 전용 filename guard)
- 제공 중: Registry freshness verifier — `scripts/verify-registry.js`가 `REBUILD_PLAYBOOK.md`, `TRACE_MATRIX.yaml`, `CURRENT_STATE.md`(Title 라인 + `완료 조건 (N/M PASS)` 완료 조건 카운트 + `최근 구현` version range 헤더)를 TypeScript AST 기반으로 live source와 대조 (`npm run registry:check`, v1.16.0+, v1.16.2+ CURRENT_STATE, v1.16.9+ locale-tolerant Title + version range, v1.16.13+ opt-in `--verify-live` 모드는 claimed PASS를 `evaluateMission()` 결과와 mechanically tie)
- 제공 중: Cold-build release gate — `reconstruction:verify --cold-build`가 release workflow 단계로 실행되어 태그된 커밋이 소스만으로 재구성 가능한지 증명 (v1.16.1+)
- 제공 중: `arch:verify` deep-compare — `package.json.exports`의 nested conditional exports 구조 재귀 비교 (v1.14.3+ key-set, v1.16.2+ value shape, v1.16.11+ nested depth)
- 제공 중: `plugin-validator` `package-lock.json` drift 감지 — lockfile이 과거 릴리스 버전에 머물러 있는 경우 포착 (v1.16.7+)
- 제공 중: `vitest.config.ts` deterministic test timeout — `testTimeout: 15000`이 `describe.concurrent`의 order-dependent flakiness 제거 (v1.16.8+)
- 제공 중: Governance MDR series — `MDR-005` meta-tooling 범위 (v1.14.2+), `MDR-006` SemVer 등급 정책 (v1.16.4+), `MDR-007` playbook 언어 Hold+Trigger (v1.16.5+)
- 미포함: GitHub/PR integration runtime, 별도 orchestration framework, SaaS/UI

## 설계 원칙

1. **Task Contract Only** — orchestration, runtime, capability는 건드리지 않음
2. **execution_hints는 suggestion** — 런타임이 무시할 수 있어야 함
3. **기존 워크플로에 녹아들기** — 별도 실행 플랫폼보다 기존 환경에 맞춤
4. **Minimal Dependencies** — Node.js + Ajv + yaml
5. **TDD First** — 테스트로 현재 범위를 고정

## Mission Spec을 사용하는 프로젝트

아직 early-stage 도구입니다. 프로젝트에서 `mission.yaml`을 durable task contract로 사용한다면, 프로젝트 이름과 한 줄 use case를 PR로 추가해 주세요. 실제 adoption signal이 feature request보다 우선순위에 더 강하게 반영됩니다.

- [qmonster](https://github.com/chquandogong/qmonster) — 여러 CLI를 tmux 기반으로 관찰하는 Rust TUI. `mission.yaml`을 phase contract로, `mission-history.yaml`을 Claude / Codex / Gemini 3-vendor adversarial-review ledger로 사용합니다.

## 라이선스

MIT
